
const sheetURL = "https://script.google.com/macros/s/PASTE_YOUR_DEPLOYED_WEB_APP_URL_HERE/exec";

function login() {
  const user = document.getElementById('username').value;
  const pass = document.getElementById('password').value;
  if ((user === 'tabrez' && pass === 'Tabrez@12') || (user === 'GNC' && pass === 'Gnc@13')) {
    document.getElementById('login').classList.add('hidden');
    document.getElementById('dashboard').classList.remove('hidden');
  } else {
    document.getElementById('login-error').innerText = "Invalid credentials.";
  }
}

document.getElementById("repairForm").addEventListener("submit", function(e){
  e.preventDefault();
  const data = {
    name: document.getElementById("name").value,
    mobile: document.getElementById("mobile").value,
    device: document.getElementById("device").value,
    issue: document.getElementById("issue").value,
    date: document.getElementById("date").value,
    cost: document.getElementById("cost").value
  };

  fetch(sheetURL, {
    method: "POST",
    body: JSON.stringify(data)
  }).then(res => res.text())
    .then(txt => {
      showReceipt(data);
    }).catch(err => {
      alert("Error saving data.");
    });
});

function showReceipt(data) {
  const content = `
    <p><strong>Customer Name:</strong> ${data.name}</p>
    <p><strong>Mobile:</strong> ${data.mobile}</p>
    <p><strong>Device:</strong> ${data.device}</p>
    <p><strong>Issue:</strong> ${data.issue}</p>
    <p><strong>Date:</strong> ${data.date}</p>
    <p><strong>Estimated Cost:</strong> ₹${data.cost}</p>
    <br><br>
    <p>Customer Signature: ____________</p>
    <p>Technician Signature: ____________</p>
  `;
  document.getElementById("receiptContent").innerHTML = content;
  document.getElementById("receipt").classList.remove("hidden");
}
